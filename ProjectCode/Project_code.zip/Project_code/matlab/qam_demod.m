function sym_rx=qam_demod(M,phs,qam_rx)                                                                                                                                    % M-ary QAM                                                                       % Modulation
H_Rx = modem.qamdemod('M', M, 'PHASEOFFSET', phs, 'SYMBOLORDER', 'BINARY', ...
                 'OUTPUTTYPE', 'BIT');                                                      % Generate Handle for Modulation
sym_rx = demodulate(H_Rx,qam_rx);                                                        % Finding out SNR from Eb/No



