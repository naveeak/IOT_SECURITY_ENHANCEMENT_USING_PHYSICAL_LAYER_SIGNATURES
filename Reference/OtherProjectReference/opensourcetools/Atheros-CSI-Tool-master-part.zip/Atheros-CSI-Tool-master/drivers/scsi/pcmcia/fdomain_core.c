#define PCMCIA 1
#include "fdomain.c"
