#define SUN3_SCSI_VME

#include "sun3_scsi.c"
