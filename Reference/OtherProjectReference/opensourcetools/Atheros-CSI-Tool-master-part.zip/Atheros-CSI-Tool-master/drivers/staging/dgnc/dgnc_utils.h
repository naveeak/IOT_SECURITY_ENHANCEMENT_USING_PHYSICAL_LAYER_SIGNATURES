#ifndef __DGNC_UTILS_H
#define __DGNC_UTILS_H

int dgnc_ms_sleep(ulong ms);

#endif
